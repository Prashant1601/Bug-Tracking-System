package com.example.demo.repository;

import com.example.demo.model.Bugs;
import com.example.demo.model.User;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BugsRepository extends CrudRepository<Bugs,Integer> {

    @Query("SELECT b from Bugs b where b.developername =:email")
    List<Bugs> findBugsByEmail(@Param("email") String email);

    @Query("SELECT e from Bugs e where e.projectname LIKE CONCAT('%',:searchkey,'%') OR e.testername LIKE CONCAT('%',:searchkey,'%') or e.developername Like CONCAT('%',:searchkey,'%') or e.bugname Like CONCAT('%',:searchkey,'%')")
    List<Bugs> getBugsByFilterRepo(@Param("searchkey") String searchkey, Sort sort);

}
