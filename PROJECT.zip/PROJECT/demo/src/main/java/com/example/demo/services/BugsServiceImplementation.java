package com.example.demo.services;

import com.example.demo.model.Bugs;
import com.example.demo.model.Student;
import com.example.demo.repository.BugsRepository;
import com.example.demo.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class BugsServiceImplementation implements BugsService{

    @Autowired
    BugsRepository bugsRepository;

    @Override
    public List<Bugs> getAllBugs() {
        return (List<Bugs>) bugsRepository.findAll();
    }

    @Override
    public Bugs getBugsById(int id) {
        return bugsRepository.findById(id).get();
    }

    @Override
    public void addBugs(Bugs bug) {
        bugsRepository.save(bug);
    }

    @Override
    public List<Bugs> findBugsByEmail(String email) {
        return bugsRepository.findBugsByEmail(email);
    }

    @Override
    public List<Bugs> getBugsByFilter(String searchkey, String orderby, String sortby) {
        Sort sort;
        if(sortby.equals("asc")){
            sort=Sort.by(Sort.Direction.ASC,orderby);
        }else{
            sort=Sort.by(Sort.Direction.DESC,orderby);
        }
        return bugsRepository.getBugsByFilterRepo(searchkey,sort);
    }

    @Override
    public void deleteBug(int id) {

        bugsRepository.deleteById(id);
    }

}
