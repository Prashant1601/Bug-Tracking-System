package com.example.demo.services;

import com.example.demo.model.Bugs;


import java.util.List;

public interface BugsService {
    public List<Bugs> getAllBugs();

    public Bugs getBugsById(int id);

    public void addBugs(Bugs Bug);
    public List<Bugs> findBugsByEmail(String email);
    public List<Bugs> getBugsByFilter(String searchkey,String orderby,String sortby);
    public void deleteBug(int id);
}