package com.example.demo.model;

import javax.persistence.*;

@Entity
@Table(name = "Bugs")
public class Bugs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;

    @Column(name="bugname")
    private String bugname;

    @Column(name="buglevel")
    private String buglevel;

    @Column(name = "priority")
    private String priority;

    @Column(name = "bugdate")
    private String bugdate;

    @Column(name = "projectname")
    private String projectname;

    @Column(name="testername")
    private String testername;

    @Column(name="status")
    private String status;

    public String getDevelopername() {
        return developername;
    }

    public void setDevelopername(String developername) {
        this.developername = developername;
    }

    @Column(name="developername")
    private String developername;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBugname() {
        return bugname;
    }

    public void setBugname(String bugname) {
        this.bugname = bugname;
    }

    public String getBuglevel() {
        return buglevel;
    }

    public void setBuglevel(String buglevel) {
        this.buglevel = buglevel;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getBugdate() {
        return bugdate;
    }

    public void setBugdate(String bugdate) {
        this.bugdate = bugdate;
    }

    public String getProjectname() {
        return projectname;
    }

    public void setProjectname(String projectname) {
        this.projectname = projectname;
    }

    public String getTestername() {
        return testername;
    }

    public void setTestername(String testername) {
        this.testername = testername;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
