package com.example.demo.repository;

import com.example.demo.model.User;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserRepository extends CrudRepository<User,Integer> {
    @Query("SELECT e from User e where e.email =:email AND e.password =:password")
    List<User> findByEmailAndPassword(@Param("email") String email, @Param("password")String password);

    @Query("SELECT e from User e where e.email =:email AND e.password =:password AND e.utype=:utype")
    List<User> findAdminByEmailAndPassword(@Param("email") String email, @Param("password")String password, @Param("utype")String utype);

    @Query("SELECT e from User e where e.email LIKE CONCAT('%',:searchkey,'%') OR e.firstname LIKE CONCAT('%',:searchkey,'%') or e.lastname Like CONCAT('%',:searchkey,'%')")
    List<User> getUserByFilterRepo(@Param("searchkey") String searchkey, Sort sort);
}
