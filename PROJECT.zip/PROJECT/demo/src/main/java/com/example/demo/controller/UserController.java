package com.example.demo.controller;


import com.example.demo.model.Bugs;
import com.example.demo.model.Student;
import com.example.demo.model.User;
import com.example.demo.services.BugsService;
import com.example.demo.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping(value="/")
public class UserController {
    @Autowired
    UserService userService;

    @Autowired
    BugsService bugsService;


    @RequestMapping(value = "/",method = RequestMethod.GET)
    public ModelAndView index(){
        ModelAndView model=new ModelAndView("index");
        return model;
    }

    @RequestMapping(value = "/userlogin",method = RequestMethod.POST)
    public ModelAndView userLogin(@ModelAttribute("userForm") User user, HttpServletResponse response,HttpSession session){
        if(userService.userLogin(user.getEmail(),user.getPassword())>0){
            session.setAttribute("useremail",user.getEmail());
            ModelAndView modelAndView=new ModelAndView();
            modelAndView.setViewName("redirect:/home");

            return  modelAndView;
        }else{

        }
        return new ModelAndView("redirect:/");
    }

    @RequestMapping(value = "/home",method = RequestMethod.GET)
    public ModelAndView home(HttpSession session, HttpServletRequest request){
        session=request.getSession();
        ModelAndView model=new ModelAndView();

        if(session.getAttribute("useremail")==null){
            model.setViewName("index");
        }else{
            String email=session.getAttribute("useremail").toString();
            if(bugsService.findBugsByEmail(email)==null || email==null){
                model.setViewName("index");
            }else{
                model.setViewName("userhome");
                List<Bugs> bugs= bugsService.findBugsByEmail(session.getAttribute("useremail").toString());
                model.addObject("bugslist",bugs);
                System.out.println(email);
                System.out.println(bugsService.findBugsByEmail(email).stream().count());

            }
        }

        return model;
    }

    @RequestMapping(value = "/newbug",method = RequestMethod.GET)
    public ModelAndView newbug(){
        ModelAndView model=new ModelAndView();
        Bugs bugs=new Bugs();
        model.addObject("userlist",userService.getAllUser());
        model.addObject("bugForm",bugs);
        model.setViewName("newbug");
        return model;
    }

    @RequestMapping(value="/editBug/{id}", method=RequestMethod.GET)
    public ModelAndView editStudent(@PathVariable int id) {
        ModelAndView model = new ModelAndView();

        Bugs bug = bugsService.getBugsById(id);
        model.addObject("userlist",userService.getAllUser());
        model.addObject("bugForm", bug);
        model.setViewName("newbug");

        return model;
    }

    @RequestMapping(value = "/addBug",method = RequestMethod.POST)
    public ModelAndView addBug(@ModelAttribute("bugForm") Bugs bug){
        ModelAndView model=new ModelAndView();
        bugsService.addBugs(bug);
        model.setViewName("userhome");
        return model;
    }

    @RequestMapping(value = "/signup",method = RequestMethod.GET)
    public ModelAndView signup(){
        ModelAndView model=new ModelAndView("signup");
        User user=new User();
        model.addObject("userForm",user);
        return model;
    }

    @RequestMapping(value="/addUser", method=RequestMethod.POST)
    public ModelAndView add(@ModelAttribute("userForm") User user) {

        userService.addUser(user);
        return new ModelAndView("redirect:/");

    }

    @RequestMapping(value = "/admin",method = RequestMethod.GET)
    public ModelAndView adminloginpage(){
        ModelAndView model=new ModelAndView("admin");
        return model;
    }

    @RequestMapping(value = "/adminlogin",method = RequestMethod.POST)
    public ModelAndView adminLogin(@ModelAttribute("adminForm") User user, HttpServletResponse response,HttpSession session){


        if(userService.findAdminByEmailAndPassword(user.getEmail(),user.getPassword(),"admin")>0){
            session.setAttribute("adminemail",user.getEmail());
            ModelAndView modelAndView=new ModelAndView();
            modelAndView.setViewName("redirect:/adminhome");

            return  modelAndView;
        }else{

        }
        return new ModelAndView("redirect:/admin");
    }



    @RequestMapping(value="/deleteBug/{id}", method=RequestMethod.GET)
    public ModelAndView delete(@PathVariable("id") int id) {

        bugsService.deleteBug(id);
        return new ModelAndView("redirect:/home");

    }



    @RequestMapping(value="/adminhome", method=RequestMethod.GET)
    public ModelAndView adminHome(String searchkey,String sortBy,String dateSort) {


        ModelAndView model=new ModelAndView();
        model.setViewName("adminhome");
        if(searchkey==null && sortBy==null && dateSort==null){
            List<User> user= userService.getAllUser();
            model.addObject("userlist",user);
        }else if(searchkey!=null && (sortBy!=null && dateSort!=null)){
            List<User> user= userService.getUserByFilter(searchkey,dateSort,sortBy);
            model.addObject("userlist",user);
        }else{
            List<User> user= userService.getAllUser();
            model.addObject("userlist",user);
        }



        return  model;

    }

    @RequestMapping(value="/adminbug", method=RequestMethod.GET)
    public ModelAndView adminBug(String searchkey,String sortBy,String dateSort) {




        ModelAndView model=new ModelAndView();
        model.setViewName("adminbug");
        if(searchkey==null && sortBy==null && dateSort==null){
            List<Bugs> bugs= bugsService.getAllBugs();
            model.addObject("bugslist",bugs);
        }else if(searchkey!=null && (sortBy!=null && dateSort!=null)){
            List<Bugs> bugs= bugsService.getBugsByFilter(searchkey,dateSort,sortBy);
            model.addObject("bugslist",bugs);
        }else{
            List<Bugs> bugs= bugsService.getAllBugs();
            model.addObject("bugslist",bugs);
        }


        return model;

    }

    @RequestMapping(value="/deleteUser/{id}", method=RequestMethod.GET)
    public ModelAndView deleteUser(@PathVariable("id") int id) {

        userService.deleteUser(id);
        return new ModelAndView("redirect:/adminhome");

    }


    @RequestMapping(value="/deleteAdminBug/{id}", method=RequestMethod.GET)
    public ModelAndView deleteAdminBug(@PathVariable("id") int id) {

        bugsService.deleteBug(id);
        return new ModelAndView("redirect:/adminbug");

    }




}
