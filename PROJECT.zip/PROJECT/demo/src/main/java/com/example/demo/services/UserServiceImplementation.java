package com.example.demo.services;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserServiceImplementation implements UserService {

    @Autowired
    UserRepository userRepository;


    @Override
    public List<User> getAllUser() {
        return (List<User>) userRepository.findAll();
    }

    @Override
    public User getUserById(int id) {
        return userRepository.findById(id).get();
    }

    @Override
    public void addUser(User user) {
        userRepository.save(user);
    }

    @Override
    public long userLogin(String email,String password) {

        return userRepository.findByEmailAndPassword(email,password).stream().count();
    }

    @Override
    public long findAdminByEmailAndPassword(String email, String password, String utype) {
        return userRepository.findAdminByEmailAndPassword(email,password,utype).stream().count();
    }

    @Override
    public List<User> getUserByFilter(String searchkey, String orderby, String sortby) {
        Sort sort;
        if(sortby.equals("asc")){
            sort=Sort.by(Sort.Direction.ASC,orderby);
        }else{
            sort=Sort.by(Sort.Direction.DESC,orderby);
        }


        return userRepository.getUserByFilterRepo(searchkey,sort);
    }

    @Override
    public void deleteUser(int id) {
        userRepository.deleteById(id);
    }

}