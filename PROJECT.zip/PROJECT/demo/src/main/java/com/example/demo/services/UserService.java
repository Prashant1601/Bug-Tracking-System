package com.example.demo.services;


import com.example.demo.model.User;

import java.util.List;

public interface UserService {
    public List<User> getAllUser();

    public User getUserById(int id);

    public void addUser(User student);

    public  long userLogin(String email,String password);
    public  long findAdminByEmailAndPassword(String email,String password,String utype);
    public List<User> getUserByFilter(String searchkey,String orderby,String sortby);
    public void deleteUser(int id);
}
